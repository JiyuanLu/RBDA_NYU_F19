/**
 * Trivial utility classes for Twitter4J client applications.
 */
package twitter4j.util;